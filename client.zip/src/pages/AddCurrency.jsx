import React from 'react';
import AddCurrencyForm from '../Components/AddCurrencyForm/AddCurrencyForm';

const AddCurrency = () => {
    return (
        <div> 
            <AddCurrencyForm/>
        </div>
    );
};

export default AddCurrency;