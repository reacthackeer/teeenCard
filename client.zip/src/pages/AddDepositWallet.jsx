import React from 'react';
import DepositWalletForm from '../Components/DepositWalletForm/DepositWalletForm';

const AddDepositWallet = () => {
    return (
        <div>  
            <DepositWalletForm/>
        </div>
    );
};

export default AddDepositWallet;