import { lesson1 } from "./1";
import { lesson10 } from "./10";
import { lesson11 } from "./11";
import { lesson12 } from "./12";
import { lesson13 } from "./13";
import { lesson14 } from "./14";
import { lesson15 } from "./15";
import { lesson16 } from "./16";
import { lesson17 } from "./17";
import { lesson18 } from "./18";
import { lesson19 } from "./19";
import { lesson2 } from "./2";
import { lesson20 } from "./20";
import { lesson21 } from "./21";
import { lesson22 } from "./22";
import { lesson23 } from "./23";
import { lesson24 } from "./24";
import { lesson25 } from "./25";
import { lesson26 } from "./26";
import { lesson27 } from "./27";
import { lesson28 } from "./28";
import { lesson29 } from "./29";
import { lesson3 } from "./3";
import { lesson30 } from "./30";
import { lesson31 } from "./31";
import { lesson32 } from "./32";
import { lesson33 } from "./33";
import { lesson34 } from "./34";
import { lesson35 } from "./35";
import { lesson36 } from "./36";
import { lesson37 } from "./37";
import { lesson38 } from "./38";
import { lesson39 } from "./39";
import { lesson4 } from "./4";
import { lesson40 } from "./40";
import { lesson41 } from "./41";
import { lesson42 } from "./42";
import { lesson43 } from "./43";
import { lesson44 } from "./44";
import { lesson45 } from "./45";
import { lesson46 } from "./46";
import { lesson47 } from "./47";
import { lesson48 } from "./48";
import { lesson49 } from "./49";
import { lesson5 } from "./5";
import { lesson50 } from "./50";
import { lesson6 } from "./6";
import { lesson7 } from "./7";
import { lesson8 } from "./8";
import { lesson9 } from "./9";

let allDatabase = [
    lesson1,
    lesson2,
    lesson3,
    lesson4,
    lesson5,
    lesson6,
    lesson7,
    lesson8,
    lesson9,
    lesson10,
    lesson11,
    lesson12,
    lesson13,
    lesson14,
    lesson15,
    lesson16,
    lesson17,
    lesson18,
    lesson19,
    lesson20,
    lesson21,
    lesson22,
    lesson23,
    lesson24,
    lesson25,
    lesson26,
    lesson27,
    lesson28,
    lesson29,
    lesson30,
    lesson31,
    lesson32,
    lesson33,
    lesson34,
    lesson35,
    lesson36,
    lesson37,
    lesson38,
    lesson39,
    lesson40,
    lesson41,
    lesson42,
    lesson43,
    lesson44,
    lesson45,
    lesson46,
    lesson47,
    lesson48,
    lesson49,
    lesson50
]

export { allDatabase };

