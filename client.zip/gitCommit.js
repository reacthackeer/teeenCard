// git initial
// git add . 
// git commit -m "Your commit"
// git branch -M "Your branch"
// git remote add origin https://github.com/Mdsohidulislam/teeenCard.git
// git push -u origin client

git init 
git add . 
git commit -m "teeenCardClient"
git branch -M "client"
git remote add origin https://github.com/Mdsohidulislam/teeenCard.git
git push -u origin client